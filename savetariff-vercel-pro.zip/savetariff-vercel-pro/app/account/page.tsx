'use client';
import { useState } from 'react';

export default function Account(){
  const [email, setEmail] = useState('');
  const [msg, setMsg] = useState<string| null>(null);

  async function openPortal(){
    const res = await fetch('/api/billing/portal', { method:'POST', headers:{'content-type':'application/json'}, body: JSON.stringify({ email })});
    const data = await res.json();
    if(data.url){ window.location.href = data.url; } else { setMsg(data.message || 'Unable to open portal'); }
  }
  function signOut(){
    document.cookie = 'st_email=; Max-Age=0; Path=/';
    document.cookie = 'st_session=; Max-Age=0; Path=/';
    window.location.href='/subscribe';
  }
  return (
    <main>
      <h1 className="text-3xl font-semibold mb-2">Account</h1>
      <p className="opacity-70 mb-4">Manage your billing and session.</p>
      <input className="border p-3 rounded-xl" placeholder="you@company.com" value={email} onChange={e=>setEmail(e.target.value)} />
      <div className="flex gap-3 mt-4">
        <button onClick={openPortal} className="btn">Open Billing Portal</button>
        <button onClick={signOut} className="btn-ghost">Sign out</button>
      </div>
      {msg && <p className="text-red-600 mt-4">{msg}</p>}
    </main>
  );
}
