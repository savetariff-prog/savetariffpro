import { NextRequest } from 'next/server';
import { signSession } from '@/lib/auth/session';

export const runtime = 'edge';

export async function POST(req: NextRequest){
  const { email } = await req.json();
  if(!email) return new Response(JSON.stringify({ message:'email required' }), { status: 400 });
  const token = await signSession(email);
  return new Response(JSON.stringify({ token }), { headers: { 'content-type':'application/json' }});
}
