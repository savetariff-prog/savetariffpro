import { NextRequest } from 'next/server';
import Stripe from 'stripe';

export const runtime = 'edge';

export async function POST(req: NextRequest){
  try{
    const { email } = await req.json();
    if(!email){ return new Response(JSON.stringify({ active:false, reason:'email_required' }), { status: 400 }); }
    const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: '2024-06-20' } as any);

    // Find customer by email
    const customers = await stripe.customers.list({ email, limit: 1 });
    const customer = customers.data[0];
    if(!customer){ return new Response(JSON.stringify({ active:false, reason:'no_customer' }), { headers: {'content-type':'application/json'}}); }

    // Check any active subscriptions
    const subs = await stripe.subscriptions.list({ customer: customer.id, status: 'active', limit: 1 });
    const active = subs.data.length > 0;
    return new Response(JSON.stringify({ active }), { headers: {'content-type':'application/json'}});
  }catch(e:any){
    return new Response(JSON.stringify({ active:false, error: e.message }), { status: 500 });
  }
}
