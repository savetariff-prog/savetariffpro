import type { Config } from 'tailwindcss'
const config: Config = {
  content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        brand: {
          navy: '#002049',
          red: '#921417',
          dark: '#000522',
          accent: '#790000',
          bg: '#F7F8FA',
          border: '#E5E7EB'
        }
      }
    }
  },
  plugins: []
}
export default config
