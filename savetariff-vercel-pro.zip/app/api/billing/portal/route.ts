import { NextRequest } from 'next/server';
import Stripe from 'stripe';

export const runtime = 'edge';

export async function POST(req: NextRequest){
  try{
    const { email } = await req.json();
    if(!email) return new Response(JSON.stringify({ message: 'email required'}), { status: 400 });
    const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: '2024-06-20' } as any);
    const customers = await stripe.customers.list({ email, limit: 1 });
    const customer = customers.data[0];
    if(!customer) return new Response(JSON.stringify({ message: 'no customer found'}), { status: 404 });
    const session = await stripe.billingPortal.sessions.create({
      customer: customer.id,
      return_url: new URL('/account', req.nextUrl.origin).toString(),
    });
    return new Response(JSON.stringify({ url: session.url }), { headers:{'content-type':'application/json'}});
  }catch(e:any){
    return new Response(JSON.stringify({ message: e.message }), { status: 500 });
  }
}
