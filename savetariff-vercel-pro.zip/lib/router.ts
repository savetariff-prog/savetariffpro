type TaskType = "duty_lookup" | "optimization" | "sop_pack" | "extraction" | "summarization" | "classification" | "ruling_draft";
type RiskKind = "legal_rate" | "adcvd" | "quota" | "origin_logic" | "none";

export interface RouteInput {
  task_type: TaskType;
  risk_kind?: RiskKind;
  strict_json?: boolean;
  cost_target?: "low"|"medium"|"high";
}

export interface RouteDecision {
  primary: "claude" | "gpt" | "deepseek";
  fallback: "gpt" | "claude" | "gpt-mini";
  policy_review: boolean;
}

export function decideRoute(req: RouteInput): RouteDecision {
  const highRisk = (req.risk_kind && ["legal_rate","adcvd","quota","origin_logic"].includes(req.risk_kind));
  if (highRisk || req.task_type === "ruling_draft" || req.task_type === "sop_pack") {
    return { primary: "claude", fallback: "gpt", policy_review: true };
  }
  if (req.strict_json || ["duty_lookup","optimization","classification"].includes(req.task_type)) {
    return { primary: "gpt", fallback: "claude", policy_review: !!req.risk_kind && req.risk_kind !== "none" };
  }
  if (req.task_type === "summarization" || req.task_type === "extraction") {
    return { primary: "deepseek", fallback: "gpt-mini", policy_review: false };
  }
  return { primary: "gpt", fallback: "claude", policy_review: false };
}
