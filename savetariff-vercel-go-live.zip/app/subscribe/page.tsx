'use client';
import { useState } from 'react';
import Link from 'next/link';

const PLANS = [
  {id: process.env.NEXT_PUBLIC_STRIPE_PRICE_MONTHLY || process.env.STRIPE_PRICE_MONTHLY, name: 'Monthly', price: '$99', blurb:'Best to start'},
  {id: process.env.NEXT_PUBLIC_STRIPE_PRICE_Q3 || process.env.STRIPE_PRICE_Q3, name: '3 Months', price: '$199', blurb:'Save $98'},
  {id: process.env.NEXT_PUBLIC_STRIPE_PRICE_H6 || process.env.STRIPE_PRICE_H6, name: '6 Months', price: '$299', blurb:'Save $295'},
  {id: process.env.NEXT_PUBLIC_STRIPE_PRICE_ANNUAL || process.env.STRIPE_PRICE_ANNUAL, name: 'Annual', price: '$299', blurb:'Best value'},
];

export default function Subscribe(){
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState<string| null>(null);
  const [msg, setMsg] = useState<string| null>(null);

  async function startCheckout(priceId:string){
    setLoading(priceId);
    const res = await fetch('/api/billing/checkout',{method:'POST', headers:{'content-type':'application/json'}, body: JSON.stringify({ email, priceId, successPath:'/' }) });
    const data = await res.json();
    setLoading(null);
    if(data.url){ document.cookie = `st_email=${email}; Path=/; SameSite=Lax`; window.location.href = data.url; }
    else { setMsg(data.message || 'Error starting checkout'); }
  }

  return (
    <section>
      <h1 className="text-4xl font-semibold mb-2">Unlock SaveTariff</h1>
      <p className="opacity-80 mb-6">Compliance-first AI orchestrator. Choose a plan to get access.</p>
      <div className="mb-4">
        <input className="border p-3 rounded-xl w-full" placeholder="you@company.com" value={email} onChange={e=>setEmail(e.target.value)} />
      </div>
      <div className="grid md:grid-cols-4 gap-4">
        {PLANS.map(p => (
          <div key={p.name} className="card p-5 flex flex-col">
            <div className="text-xl font-semibold">{p.name}</div>
            <div className="text-3xl mt-2">{p.price}</div>
            <div className="opacity-70 text-sm">{p.blurb}</div>
            <ul className="text-sm mt-4 space-y-1">
              <li>• Full chatbot access</li>
              <li>• Optimization Canvas</li>
              <li>• SOP Pack generator</li>
              <li>• Sector playbooks</li>
            </ul>
            <button onClick={()=>startCheckout(p.id!)} disabled={!email || loading===p.id} className="btn mt-6">
              {loading===p.id ? 'Redirecting…' : 'Subscribe'}
            </button>
          </div>
        ))}
      </div>
      {msg && <p className="text-red-600 mt-4">{msg}</p>}
      <p className="text-sm opacity-70 mt-6">Already a customer? <Link href="/account" className="underline">Manage your subscription</Link>.</p>
    </section>
  );
}
