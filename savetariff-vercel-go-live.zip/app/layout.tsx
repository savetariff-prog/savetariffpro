import './styles/globals.css';
import Image from 'next/image';
import Link from 'next/link';

export const metadata = {
  title: 'SaveTariff',
  description: 'Compliance-first tariff optimization'
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <header className="sticky top-0 z-10 bg-white/70 backdrop-blur border-b border-brand-border">
          <div className="max-w-6xl mx-auto flex items-center justify-between p-3">
            <div className="flex items-center gap-2">
              <Image src="/logo.png" alt="SaveTariff" width={40} height={40}/>
              <span className="font-semibold">SaveTariff</span>
            </div>
            <nav className="flex items-center gap-3">
              <Link className="btn-ghost" href="/">Dashboard</Link>
              <Link className="btn-ghost" href="/subscribe">Pricing</Link>
              <Link className="btn" href="/account">Account</Link>
            </nav>
          </div>
        </header>
        <main className="max-w-6xl mx-auto p-6">
          {children}
        </main>
        <footer className="border-t border-brand-border mt-10 py-6 text-sm text-center opacity-70">
          © {new Date().getFullYear()} SaveTariff.com — Compliance-first routing
        </footer>
      </body>
    </html>
  );
}
