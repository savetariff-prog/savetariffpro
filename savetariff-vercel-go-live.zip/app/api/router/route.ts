import { NextRequest } from "next/server";
import { cfg, ensureEnv } from "@/lib/config";
import { decideRoute } from "@/lib/router";
import * as TP from "@/lib/tools/tariff_portal";
import * as TM from "@/lib/tools/trade_measures";
import * as VAT from "@/lib/tools/vat_excise";
import * as LC from "@/lib/tools/landed_cost";
import * as DOC from "@/lib/tools/docs";
import * as RUL from "@/lib/tools/rulings";
import * as RAG from "@/lib/tools/retrieval";

export const runtime = "edge";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { task_type, payload, risk_kind, strict_json } = body || {};
    const route = decideRoute({ task_type, risk_kind, strict_json });
    // Ensure keys for the chosen model (basic guard)
    if (route.primary === "gpt") ensureEnv(["openaiKey"]);
    if (route.primary === "claude") ensureEnv(["anthropicKey"]);
    if (route.primary === "deepseek") ensureEnv(["deepseekKey"]);

    // Minimal gating: for any high-risk claim, require portals to be healthy/cited
    const needsCitations = ["legal_rate","adcvd","quota","origin_logic"].includes(risk_kind);

    // Call tools depending on task
    let tools:any = {};
    if (task_type === "duty_lookup" || task_type === "optimization") {
      tools.tariff = await TP.tariff_portal(payload?.tariff_query || {});
      tools.measures = await TM.trade_measures(payload?.measures_query || {});
      tools.vat = await VAT.vat_excise(payload?.vat_query || {});
    }
    if (task_type === "sop_pack") {
      tools.pack = await DOC.docs(payload?.docs_query || {});
    }
    if (task_type === "ruling_draft") {
      tools.ruling = await RUL.rulings(payload?.rulings_query || {});
    }
    // Retrieval for internal guidance
    const rag = await RAG.retrieval(payload?.retrieval_query || {});

    // Citation & portal health gate
    const cited = (arr:any[]) => Array.isArray(arr) && arr.length > 0;
    const portalHealthy = !["degraded","error"].includes(tools?.tariff?.status) && !["degraded","error"].includes(tools?.measures?.status);
    if (needsCitations && (!portalHealthy || !(cited(tools?.tariff?.source_citations)||cited(tools?.measures?.source_citations)))) {
      return new Response(JSON.stringify({
        status: "blocked",
        error_code: "MISSING_CITATIONS",
        reason: "Official portal citations required or portal health degraded",
        publish_blocked: true,
        tools
      }, null, 2), { status: 400, headers: { "content-type": "application/json" }});
    }

    // Return a simple merged payload to the UI for now
    return new Response(JSON.stringify({
      status: "ok",
      route,
      tools,
      rag_hits: rag?.hits || [],
      note: "This is a scaffold. Connect tool stubs to real portals and add providers."
    }, null, 2), { headers: { "content-type": "application/json" }});
  } catch (e:any) {
    return new Response(JSON.stringify({ status:"error", message: e.message }), { status: 500 });
  }
}
