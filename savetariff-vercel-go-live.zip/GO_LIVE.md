# SaveTariff — Go-Live Checklist (Vercel)

1) **Create Project** in Vercel and import this folder.
2) **Environment Variables** (Production + Preview + Development):
   - OPENAI_API_KEY
   - DEEPSEEK_API_KEY
   - ANTHROPIC_API_KEY (optional)
   - STRIPE_SECRET_KEY
   - STRIPE_PRICE_MONTHLY
   - STRIPE_PRICE_Q3
   - STRIPE_PRICE_H6
   - STRIPE_PRICE_ANNUAL
   - STRIPE_WEBHOOK_SECRET (after step 5)
   - POSTGRES_URL
   - PRISMA_DATABASE_URL
   - SAVETARIFF_SIGNING_SECRET (random string)
3) **Deploy**.
4) **Initialize DB** (run once, locally):
   ```bash
   npm install
   npm run prisma:push
   ```
   (This creates tables in your cloud database.)
5) **Stripe Webhook**:
   - Add endpoint: `https://YOURDOMAIN/api/billing/webhook`
   - Events: checkout.session.completed, customer.subscription.updated, customer.subscription.deleted
   - Paste signing secret as STRIPE_WEBHOOK_SECRET in Vercel
6) **Smoke Tests**:
   - `https://YOURDOMAIN/api/health` → `{ ok: true }`
   - `https://YOURDOMAIN/api/db/health` → `{ ok: true }`
   - `https://YOURDOMAIN/subscribe` loads pricing
   - After subscribing, `/` loads the app (otherwise redirects to /subscribe).

If any step fails, redeploy and review the Vercel build logs.
