# SaveTariff — Vercel Starter

This is a minimal, compliance-first scaffold that deploys to Vercel and includes:
- App Router UI (Next.js 14)
- Serverless API route `/api/router` with policy-aware model router
- Tool stubs (`tariff_portal`, `trade_measures`, `vat_excise`, `landed_cost`, `docs`, `rulings`, `retrieval`)
- Environment-driven provider keys (OpenAI, Anthropic, DeepSeek)

## Quick start (local)
```bash
npm i
cp .env.example .env.local
# Fill in keys
npm run dev
```

## Deploy to Vercel
1) Create a new project on Vercel and import this repo.
2) Add Environment Variables (Production/Preview/Development):
   - OPENAI_API_KEY
   - ANTHROPIC_API_KEY
   - DEEPSEEK_API_KEY
   - SAVETARIFF_SIGNING_SECRET (create a random string)
3) Deploy.

## API
POST /api/router
Body:
```
{ "task_type": "duty_lookup|optimization|sop_pack|extraction|summarization|classification|ruling_draft",
  "payload": { ... },
  "risk_kind": "legal_rate|adcvd|quota|origin_logic|none",
  "strict_json": true
}
```

## Paywall (Stripe Subscription)
- Visit `/subscribe` to start a Checkout session.
- A cookie `st_email` is set on the root page; middleware calls `/api/auth/check` to verify an **active** subscription in Stripe for that email, otherwise redirects to `/subscribe`.
- Set these env vars in Vercel:
  - `STRIPE_SECRET_KEY`
  - `STRIPE_WEBHOOK_SECRET` (after creating webhook endpoint pointing to `/api/billing/webhook`)
  - `STRIPE_PRICE_MONTHLY`, `STRIPE_PRICE_Q3`, `STRIPE_PRICE_H6`, `STRIPE_PRICE_ANNUAL`

## Added (Head-of-Engineering polish)
- Tailwind design system with brand tokens (Adobe-style cards, rounded-2xl, soft shadows).
- Stripe Customer Portal (`/api/billing/portal`) + `/account` page.
- Webhook endpoint (`/api/billing/webhook`) for subscription lifecycle events.
- Signed session cookie (`st_session`) using HMAC JWT with `SAVETARIFF_SIGNING_SECRET`.
- Middleware paywall checking active Stripe subscription every visit.
- Basic CSP header and request gating in the router for missing citations.
