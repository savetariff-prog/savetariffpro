'use client';
import Image from 'next/image';
import { useState } from 'react';

async function createSession(email:string){
  const res = await fetch('/api/session', { method:'POST', headers:{'content-type':'application/json'}, body: JSON.stringify({ email })});
  if(res.ok){
    document.cookie = `st_email=${email}; Path=/; SameSite=Lax`;
    const { token } = await res.json();
    document.cookie = `st_session=${token}; Path=/; SameSite=Lax`;
  }
}

export default function Home() {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [email, setEmail] = useState('');
  const [form, setForm] = useState({
    hs: "",
    origin: "IN",
    dest: "US",
    incoterm: "FOB",
    value: 10000,
    qty: 1000,
    program: ""
  });

  async function submit() {
    setLoading(true);
    setResult(null);
    if(email) await createSession(email);
    const payload = {
      tariff_query: { country: form.dest, hs10: form.hs, origin: form.origin, program: form.program },
      measures_query: { hs10: form.hs, origin: form.origin, dest: form.dest },
      vat_query: { dest: form.dest, hs10: form.hs, customs_value: form.value, incoterm: form.incoterm, currency: "USD" },
      retrieval_query: { query: `HS ${form.hs} ${form.origin}->${form.dest}`, filters: { hs_code: form.hs }, top_k: 6 }
    };
    const res = await fetch('/api/router', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ task_type: 'duty_lookup', risk_kind: 'legal_rate', strict_json: true, payload })
    });
    const json = await res.json();
    setResult(json);
    setLoading(false);
  }

  return (
    <main className="space-y-6">
      <div className="card p-6 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Image src="/logo.png" alt="SaveTariff" width={56} height={56} />
          <div>
            <h1 className="text-2xl font-semibold">Tariff Intelligence</h1>
            <p className="opacity-70 text-sm">Compliance-first lookup with portal citation gates.</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <input className="border p-2 rounded-xl" placeholder="you@company.com" value={email} onChange={e=>setEmail(e.target.value)} />
          <button onClick={()=>createSession(email)} className="btn-ghost">Save Email</button>
        </div>
      </div>

      <div className="card p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <label className="flex flex-col">HS/Description<input className="border p-2 rounded" value={form.hs} onChange={e=>setForm({...form, hs:e.target.value})}/></label>
          <label className="flex flex-col">Origin<input className="border p-2 rounded" value={form.origin} onChange={e=>setForm({...form, origin:e.target.value})}/></label>
          <label className="flex flex-col">Destination<input className="border p-2 rounded" value={form.dest} onChange={e=>setForm({...form, dest:e.target.value})}/></label>
          <label className="flex flex-col">Incoterm<input className="border p-2 rounded" value={form.incoterm} onChange={e=>setForm({...form, incoterm:e.target.value})}/></label>
          <label className="flex flex-col">Value (USD)<input type="number" className="border p-2 rounded" value={form.value} onChange={e=>setForm({...form, value: Number(e.target.value)})}/></label>
          <label className="flex flex-col">Qty<input type="number" className="border p-2 rounded" value={form.qty} onChange={e=>setForm({...form, qty: Number(e.target.value)})}/></label>
          <label className="flex flex-col">Program (optional)<input className="border p-2 rounded" value={form.program} onChange={e=>setForm({...form, program:e.target.value})}/></label>
        </div>
        <button onClick={submit} disabled={loading} className="btn mt-4">
          {loading ? 'Checking…' : 'Check Duty'}
        </button>
      </div>

      <pre className="card p-4 overflow-auto text-sm">{result ? JSON.stringify(result, null, 2) : 'Result will appear here'}</pre>
    </main>
  );
}
