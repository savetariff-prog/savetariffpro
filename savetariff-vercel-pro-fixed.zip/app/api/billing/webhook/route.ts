import { headers } from 'next/headers';
import { NextRequest } from 'next/server';
import Stripe from 'stripe';

export const runtime = 'nodejs'; // Stripe requires Node crypto for signature verification

export async function POST(req: NextRequest){
  const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: '2024-06-20' } as any);
  const buf = Buffer.from(await req.arrayBuffer());
  const sig = (await headers()).get('stripe-signature') as string;
  const endpointSecret = process.env.STRIPE_WEBHOOK_SECRET!;
  let event: Stripe.Event;

  try {
    event = stripe.webhooks.constructEvent(buf, sig, endpointSecret);
  } catch (err:any) {
    return new Response(`Webhook Error: ${err.message}`, { status: 400 });
  }

  // Minimal logging; you can extend to persist to DB
  console.log('Stripe event', event.type);

  return new Response(JSON.stringify({ received: true }), { status: 200 });
}
