export default function NotFound(){
  return (
    <main className="p-8 space-y-4">
      <h1 className="text-3xl font-semibold">Page not found</h1>
      <p>Try our public pages:</p>
      <ul className="list-disc list-inside">
        <li><a className="underline" href="/subscribe">/subscribe</a> (pricing)</li>
        <li><a className="underline" href="/api/health">/api/health</a> (app health)</li>
        <li><a className="underline" href="/api/db/health">/api/db/health</a> (database health)</li>
      </ul>
    </main>
  );
}
