import { NextRequest } from 'next/server';
import Stripe from 'stripe';

export const runtime = 'edge';

export async function POST(req: NextRequest){
  try{
    const { email, priceId, successPath='/' } = await req.json();
    if(!email || !priceId){
      return new Response(JSON.stringify({ message: 'Email and priceId required'}), { status: 400 });
    }
    const sk = process.env.STRIPE_SECRET_KEY!;
    const stripe = new Stripe(sk, { apiVersion: '2024-06-20' } as any);

    const session = await stripe.checkout.sessions.create({
      mode: 'subscription',
      customer_email: email,
      line_items: [{ price: priceId, quantity: 1 }],
      allow_promotion_codes: true,
      success_url: `${new URL(successPath, req.nextUrl.origin).toString()}?success=1`,
      cancel_url: `${new URL('/subscribe', req.nextUrl.origin).toString()}?canceled=1`,
    });

    return new Response(JSON.stringify({ url: session.url }), { headers: {'content-type':'application/json'}});
  }catch(e:any){
    return new Response(JSON.stringify({ message: e.message || 'error' }), { status: 500 });
  }
}
