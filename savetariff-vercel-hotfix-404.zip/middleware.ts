import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

const PUBLIC_PATHS = ['/_next', '/favicon', '/api/billing', '/subscribe', '/logo.png'];

export async function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;
  if (PUBLIC_PATHS.some(p => pathname.startsWith(p))) return NextResponse.next();

  // Gate the root page and any future app pages
  const email = req.cookies.get('st_email')?.value; const session = req.cookies.get('st_session')?.value;
  if (!email) {
    return NextResponse.redirect(new URL('/subscribe', req.url));
  }

  // Validate subscription status
  const res = await fetch(new URL('/api/auth/check', req.url).toString(), {
    method: 'POST',
    headers: { 'content-type':'application/json' },
    body: JSON.stringify({ email })
  });

  const data = await res.json();
  if (!data.active) {
    // Clear cookie and redirect
    const resp = NextResponse.redirect(new URL('/subscribe', req.url));
    resp.cookies.delete('st_email');
    return resp;
  }
  return NextResponse.next();
}

export const config = {
  matcher: [
    '/',               // root
    '/subscribe',      // pricing
    '/account',        // account
    '/((?!api|_next|static|public|favicon.ico|.*\..*).*)', // any non-file path
  ],
};
