import type { NextRequest } from "next/server";

export interface ToolRequest { tenant_id?: string; request_id?: string; [k: string]: any; }
export interface ToolResponse { source_citations?: any[]; [k: string]: any; }

export async function tariff_portal(req: ToolRequest): Promise<ToolResponse> {
  // TODO: Connect to official portals/APIs. This is a stub that returns 'degraded' to enforce citations gate.
  return {
    status: "degraded",
    note: "tariff_portal not yet connected to official portal",
    source_citations: []
  };
}
