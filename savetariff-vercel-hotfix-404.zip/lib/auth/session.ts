function b64u(buf: ArrayBuffer): string {
  return Buffer.from(buf).toString('base64').replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
}

export async function signSession(email: string, ttlSeconds=86400): Promise<string> {
  const exp = Math.floor(Date.now()/1000)+ttlSeconds;
  const payload = { email, exp };
  const enc = new TextEncoder();
  const header = b64u(enc.encode(JSON.stringify({ alg:'HS256', typ:'JWT' })));
  const body = b64u(enc.encode(JSON.stringify(payload)));
  const data = `${header}.${body}`;
  const key = await crypto.subtle.importKey('raw', enc.encode(process.env.SAVETARIFF_SIGNING_SECRET||''), { name:'HMAC', hash:'SHA-256'}, false, ['sign','verify']);
  const sig = await crypto.subtle.sign('HMAC', key, enc.encode(data));
  return `${data}.${b64u(sig)}`;
}

export async function verifySession(token: string): Promise<{email:string}|null> {
  try{
    const enc = new TextEncoder();
    const [h,b,s] = token.split('.');
    const data = `${h}.${b}`;
    const key = await crypto.subtle.importKey('raw', enc.encode(process.env.SAVETARIFF_SIGNING_SECRET||''), { name:'HMAC', hash:'SHA-256'}, false, ['sign','verify']);
    const ok = await crypto.subtle.verify('HMAC', key, Buffer.from(s.replace(/-/g,'+').replace(/_/g,'/'),'base64'), enc.encode(data));
    if(!ok) return null;
    const payload = JSON.parse(Buffer.from(b.replace(/-/g,'+').replace(/_/g,'/'),'base64').toString('utf8'));
    if(payload.exp < Math.floor(Date.now()/1000)) return null;
    return { email: payload.email };
  }catch{ return null; }
}
