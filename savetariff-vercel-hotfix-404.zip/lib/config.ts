export const cfg = {
  openaiKey: process.env.OPENAI_API_KEY || "",
  anthropicKey: process.env.ANTHROPIC_API_KEY || "",
  deepseekKey: process.env.DEEPSEEK_API_KEY || "",
  signingSecret: process.env.SAVETARIFF_SIGNING_SECRET || "",
};
export function ensureEnv(keys: (keyof typeof cfg)[]) {
  const missing = keys.filter(k => !cfg[k]);
  if (missing.length) {
    throw new Error("Missing environment variables: " + missing.join(", "));
  }
}
